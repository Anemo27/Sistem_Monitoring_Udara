Application note
=======
To prevent noise and inaccuracy, please :

1. Do not put DSM501 in the sun, temperature and the light might affect the sensor.
 
2. Do not put DSM501 in under a light source, since the readings will be affected by the light.

3. Must be use low noise power supply to prevent noise at the analog output.


